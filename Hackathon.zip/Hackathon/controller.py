from flask import render_template,request,redirect,url_for,jsonify,session,flash
import re
import sys
from config import app,db,mycursor
from flask.wrappers import Request

global skills 
skills = []

@app.route('/',methods = ['POST','GET'])
def home():
    if request.method== 'GET':
        return render_template("login.html")
    elif request.method== 'POST':
        p1 = request.form.get('email')
        p2 = request.form.get('fname')
        p3 = request.form.get('gender')
        p4 = request.form.get('age')
        p5 = request.form.get('exp')
        p6 = request.form.get('skills')
        skills = p6
        print(skills)
        db.session.execute("insert into user_table(email,f_name,gender,age,experience,skills) values('{}','{}','{}','{}','{}','{}')".format(p1,p2,p3,p4,p5,p6))
        db.session.commit()
        return render_template("job.html")

@app.route('/apply',methods = ['POST','GET'])
def apply():
    if request.method == 'GET':
        return render_template("job.html")

    elif request.method == 'POST':
         res = db.session.execute("select job_skills from job where ")
if __name__ == '__main__':
       app.run(debug = True)
    